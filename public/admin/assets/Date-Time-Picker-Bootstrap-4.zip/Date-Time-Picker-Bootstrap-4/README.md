# Datetimepicker for Bootstrap 4
[![Build Status](https://travis-ci.org/pingcheng/bootstrap4-datetimepicker.svg?branch=master)](https://travis-ci.org/pingcheng/bootstrap4-datetimepicker)

The js and css files had been changed to the suit Boostrap 4.

Since Bootstrap 4 removed the glyphicon, I replaced all icons with fontawesome, please includes the fontawesome css as well.

Click [here](http://eonasdan.github.io/bootstrap-datetimepicker/) for the offical usage documentation.

## Changes

* JS DOM class name control
* CSS stylessheet
* Replaced glyphicon with fontawesome icons
